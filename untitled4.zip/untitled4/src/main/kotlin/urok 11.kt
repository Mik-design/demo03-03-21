//fun main () {
//    val names = arrayOf("KG", "RU", "USA", "TR")
//    val codes = arrayOf("+996", "+7", "+1", "+90")
//
//    val myMap = HashMap<String, String>()
//    println(myMap.entries)
//
////
////    for(name:String in names){
////        println(name)
////    }
////names.forEach{println(it)}
//////    myMap=HashMapOf()
//
//}