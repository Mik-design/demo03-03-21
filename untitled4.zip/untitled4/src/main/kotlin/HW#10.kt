import kotlin.test.assertEquals

//import kotlin.test.assertEquals

//import java.util.*
//import kotlin.collections.HashMap
//import kotlin.collections.LinkedHashMap
//import kotlin.String as String
//
//fun main () {
//    //Map
//
//    val password = "12345"
//    val username = "onepunch_1"
//    val name = "Santa"
//
////    val list = arrayListOf("12345", "onepunch_1", "John")
//////    list[0]
////    //key value
//
////     val anotherMap = HashMap<String, String>()
//    val myMap = HashMap<String, String>()
//    myMap.put("password", "12345")
//    myMap.put("username", "onepunch_1")
//    myMap.put("name", "Santa")
//    myMap.put("name3", "Malta")
//    myMap.put("name1", "Fay")
//
////    myMap.remove("name")
//    println(myMap.entries)
//    println(myMap.get("password"))
//
//    //Set
//
//    val mySet = HashSet<Int>()
////    mySet.add(1)
////    mySet.add(2)
////    mySet.add(3)
////    mySet.add(4)
////    mySet.add(4)
////    mySet.add(4)
////    mySet.add(1)
////    mySet.add(1)
//
//    val list = arrayListOf(1,2,3,4,4,4,1,1)
//    mySet.addAll(list)
//println(mySet)
//
//}
//fun main()
//{
//    val itemCosts = mapOf("Хлеб" to 50.0, "Кефир" to 0.0, "Сыр" to 0.0)
//    val shoppingList = listOf("Хлеб", "Кефир", "Сыр")
//    var totalCost = 50.0
//
////    println(itemCost["Хлеб"])
//    for (itemCost in itemCosts) {
////        println("${itemCost.key} - ${itemCost.value}")
////        println("${item.Cost.key} -${itemCost.value}")
//    }
////    println(itemCosts.javaClass)
//    println("Общая стоимость - 50.0")
//}
