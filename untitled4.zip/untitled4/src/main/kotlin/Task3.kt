//var value: String? = null
//lateinit var LateValue: String
//fun main () {
//
////    value = "Kotlin"
//
//    //Safe call operator(?.)
////    println(value?.length)
//
//    //Safe call with let (?.let)
//    value?. let{ String
////        println(it.length)
//
//    }
//    //Elvis operator(?:)
//    val length = if(value != null) {
//        value!!.length
//    } else {
//        -1
//    }
//    val length2 = value?.length?: -1
////        println(length2)
//    //Non null assertion operator(!!)
////    println(value!!.length)
//
//    //'lateinit' keyword
//    LateValue = "Java"
//    println(LateValue.length)
//}

fun main(){
    var a = 5
    var b = 5

    var combined = (a + b)
    println(combined)
    var c = 4
    var d = 2

    var difference = (c-d)
    println(difference)


}