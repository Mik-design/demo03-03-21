////fun main (){
////    //*Array//
////
//////    val a = 1
//////    val b = 3
//////    val c = 2
////
////    //element: 42 0 0 0 332
////    //index:   0 1 2 3 4
////
//////    val myArray: Array<Int> = Array(5) {0}
////    val myArray = arrayOf(1, 2, 3, 4, 5)
//////    val myArrayList = ArrayList<Int>()
////
////    myArray[0] = 42
////    myArray[4] = 332
////
//////    myArrayList.add(10)
////
////    println(myArray[0])
////    println(myArray[1])
////
////    /*ArrayList*/
////    val myArrayList = ArrayList<String>()
////
////    myArrayList.add("Kotlin")
////    myArrayList.add("Java")
////    myArrayList.add("Dart")
////
////    myArrayList.add(1, "Python")
////    myArrayList.removeAt(2)
////    myArrayList.remove("Java")
////
////    println(myArrayList)
////    println(myArrayList.size)
////
////}
//
//fun main () {
//
//    val array1 = arrayOf(1,2,3)
//    val array2 = arrayOf(4,5,6)
//
//    val array3 = arrayOf(1, 2, 3, 4, 5, 6)
//    println(array3.sum())//1-e zadanie
//
//    val myArray = arrayOf(5, -3, 15, 61, 29, 10, -2, 7)
//    println (myArray.max())//2-e zadanie
//}
















