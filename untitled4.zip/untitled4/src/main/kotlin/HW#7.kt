fun main() {
    val a = 2
    if (a % 2 == 0) {
        println("a is even")
    } else if (a % 2 != 0 && a % 5 == 0) {
        println("a divisible by 5 ")
    } else {
        println("a znak even and divisible by 5")

    }
}


//fun main () {
//    val a = 2
//    when {
//        a%2== 0 -> println("a is even")
//        a % 2 != 0 && a % 5 == 0 -> println("a divisible by 5 ")
//        else  -> {
//            println("a znak even and divisible by 5")
//
//        }
//        }
//}

