fun main () {
//    var num = 9
//    num ++
//    num+=6
//    --num
//    println(num)
//    val listA=mutableListOf(1, 2, 3)
//    val listB=listA.add(4)
//    print(listB)
//    var number:Float=45
//    val a:String?=null
//    val b:String ="Hello World"
//    println(a==b)
//    val l:Long = (Long)*42*
//    val l:Long=Long.parselLong("42")
//    val l:Long=<Long>"42"
//    val l:Long="42".toLong()
////    val l:Long=Lo
//    var str : String=null


}