//fun main() {
//    //for Loop
//    val names: ArrayList<String> = arrayListOf("Kotlin", "Java", "Dart")
//
////    for(i in 0 until names.size){
////        println(names[i])//zdes est index
////    }
//    for (name: String in names) {//no index
//        println(name)
//    }
//    names.forEach { println(it) }//no index
//    names.forEachIndexed { index, name ->
//        println("$index $name")
//    }//est index &element
//
////    for(i in 0..10 step 2) {
////        println(i)
////    }
////    for(i in 10 downTo 0 step 2) {
////        println(i)
////    }
//    for (i in 0..10) {//continue / break
//        if (i == 6) break //continue
//        println(i)
//    }
//
//    println("________________________________")
//    //while
////    while(true){
////        //println("while")
////    }
//    var j = 11
//
//    while(j <= 10){
//        println("while $j")
//        j++
//
//    }
//    //do while
//    println("________________________________")
//    var k = 11
//
//    do {
//        println("do while $k")
//        k++
//    }while (k<=10)
//
//
//    }
//fun main() {
//
//    for (i in 0 until 4) {
//        for (j in 0 until 4) {
//            print(" * ")
//        }
//        println(" * ")
//    }
//
//    var k = 5
//
//    do {
//        println("             *")
//        println("           * *")
//        println("       *  *  *")
//        println("    *  *  *  *")
//        println(" *  *  *  *  *")
//
//        k++
//    }while (k==5)//1-e zadanie
//}
//    fun main () {
//    var n = "58989"
//    println(n?.length)//2-e zadanie
//    }
//
//fun main () {
//
//    var a = 0
//    var b = 1
//    while (a<20){
//        b *=2
//        print(b)
//        a ++
//    }//3-e zadanie
//
//}
