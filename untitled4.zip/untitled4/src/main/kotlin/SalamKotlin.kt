fun main () {
    val name = "Mari"
    val name2 = "Kay"

    val combined = "$name $name2"
    println(combined)

}