//fun main () {
    //var a = readLine()!!.toInt()
    //var b = readLine()!!.toInt()
    //println ("a=$a b=$b")
    //a=a+b
    //b=a-b
    //a=a-b
    //println ("a=$a b=$b")

//}
