////fun main () {
////    if (false) {
////        println ("if block called")
////    }
////}
////val a = 3
////val b = 2
////if (a >b) {
////}
////val bool = a!=b
////if (bool)
////if (a==b && a>b)
////
////if (false) {
////    println ("if block called")
////} else {
////    println ("else block called")
////}
//fun main () {
//    val score = 100
//    if (score >=90 && score <=100) {
//        println ("5")
//    } else if (score >=70 && score <90) {
//        println ("4")
//    } else if (score >=50 && score <70) {
//        println ("3")
//    } else if (score >=30 && score <50) {
//        println ("2")
//    } else if (score >=0 && score <30) {
//        println ("1")
//    } else {
//        println ("invalid score")
//    }
//    }
//
//    val a = 5
//    val b = 3
////    val maxValue = if(a>b) {
////        a
////    }else  {
////        b
////        println ("maxValue:$ maxValue")
////    }
//
//
//    val maxValue = if(a > b) {
//    println ("a is bigger")
//    a
//}
//    else
//        b

//fun main (){
//    println("Введите четырехзначное число: ")
//    println("6748")
//
//    val n1 = 6
//    val n2 = 7
//    val n3 = 4
//    val n4 = 8
//
//
//    if (n1+n2==n3+n4) {
//        println("true")//1st task
//    } else {
//        println("false")
//    }
//}

fun main () {
    var age = 38

    if (age <= 200 && age >= 1) {
        println ("21 год, 32 года, 12 лет")
    } else {
    println ("Не то, что надо")
}
}