//fun main() {
//    var a = 10
//    val b = 3
//
//    println("a++:${a++}")
//    println("++a:${++a}")//increament
//    println("a--:${a--}")
//    println("--a:${--a}")//decreament
//
//    println("-a=${-a}")//negative meaning
//
//    val sum = a + b
//
////  println (sum)// 1-e решение
////  println (a + b)// 2-e решение
//    println ("a+b=${a+b}")// 3-е решение
//
//    println ("a - b = ${a - b}")
//    println ("a * b = ${a * b}")
//    println ("a / b = ${a / b}")
//    println ("a%b = ${a % b}")
//    println ("2+2*5 = ${(2+2)*5}")
//
//    a = a + 2
//    println (a)
//
//    a+= 2// type without space
//    println("a+ = 2: $ a")
//    a-= 2
//    println("a-=2:$a")
//    a*=2
//    println("a*=2:$a")
//    a/=2
//    println("a/=2:$a")
//    a%= 2
//    println("a %=2:$a") // module
//}

//
//fun main () {
//    println("ax^2 + bx + c = 0")
//    println("Введите a, b и c:")
//    println("1")
//    println("-8.5")
//    println("15")
//
//    val a = 1
//    val b = -8.5
//    val c = 15
//    val d: Double
//
//
//    fun discriminant(a: Double, b: Double, c: Double) = b * b - 4 * a * c
//    d = b * b - 4 * a * c
//
//
//    if (d>0) {
//        val x1: Double
//        val x2: Double
//        x1 = (-b - Math.sqrt(d))/(2*a)
//        x2 = (-b + Math.sqrt(d))/(2*a)
//
//        println("Корни уравнения: x1=$x1, x2=$x2")
//
//    } else if (d == 0.0) {
//        val x: Double
//        x = -b / (2 * a)
//        println("Уравнение имеет единственный корень: x=$x")
//    } else {
//        println("Уравнение не имеет действительных корней!")//1-e zadanie
//    }
//}
//
//fun main (){
//    var a = 5
//    var b = 9
////    var a = readLine()!!.toInt(5)
////    var b = readLine()!!.toInt(9)
//    val c: Int
//    println("a=$a b=$b")
//    c=a
//    a=b
//    b=c
//    println("a=$a b=$b")//3-e zadacha (1-e reshenie)
//}

fun main () {
    var hoursDepart = 9.0
    var minutesDepart = 25
    var hoursArrive = 13.0
    var minutesArrive = 1

    var d:Double
    d = (hoursArrive*60 + minutesArrive) - (hoursDepart*60 + minutesDepart)


    println(d)

//    fun travelMinutes(hoursDepart:Int, minutesDepart:Int, hoursArrive:Int, minutesArrive:Int):Int=TODO()
//    fun travelMinutes(hoursDepart:9, minutesDepart:25, hoursArrive:13, minutesArrive:01):Int=TODO()


}



